﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebStore.DomainNew.Models.BreadCrumb
{
    public enum BreadCrumbType
    {
        None = 0,
        Section = 1,
        Brand = 2,
        Item = 3
    }
}
