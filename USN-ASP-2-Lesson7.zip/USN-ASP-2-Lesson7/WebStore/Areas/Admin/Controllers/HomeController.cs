﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebStore.DomainNew.Filters;
using WebStore.DomainNew.Model;
using WebStore.Interfaces;

namespace USNWebStore.Areas.Admin.Controllers
{
    [Area("Admin")]                            // Обязательно добавляем атрибут
    //[Authorize(Roles = Const.Roles.Administrator)]
    public class HomeController : Controller
    {
        private readonly IProductData _productData;
        public HomeController(IProductData productData)
        {
            _productData = productData;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ProductList()
        {
            var products = _productData.GetProducts(new ProductFilter());
            return View(products);
        }

    }
}