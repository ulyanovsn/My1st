﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebStore.DomainNew.Models;
using WebStore.Infrastructure.Interfaces;

namespace USNWebStore.Controllers
{
    public class WorkersController : Controller
    {
        private readonly IWorkersData _workersData;

        public WorkersController(IWorkersData workersData)
        {
            _workersData = workersData;
        }

        public IActionResult Index()                        // страница Index
        {
            return View(_workersData.GetAll());
        }

        public IActionResult Details(int id)          // страница details
        {
            var worker = _workersData.GetById(id);

            if (ReferenceEquals(worker, null)) return NotFound(); // ошибка 404
            return View(worker);                //возвращаем сотрудника
        }
        [Route("edit/{id?}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult Edit(int? id)
        {
            WorkerView model;
            if (id.HasValue)
            {
                model = _workersData.GetById(id.Value);
                if (ReferenceEquals(model, null)) return NotFound(); // возвращаем результат 404 Not Found
            }
            else
            {
                model = new WorkerView();
            }
            return View(model);
        }
        [HttpPost]
        [Route("edit/{id?}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult Edit(WorkerView model)
        {
            if (model.Age < 18 && model.Age > 100)
            {
                ModelState.AddModelError("Age", "Ошибка возраста!");
            }
            // Проверяем модель на валидность
            if (ModelState.IsValid)
            {
                if (model.Id > 0)
                {
                    var dbItem = _workersData.GetById(model.Id);
                    if (ReferenceEquals(dbItem, null)) return NotFound();      // возвращаем результат 404 Not Found

                    dbItem.FirstName = model.FirstName;
                    dbItem.SurName = model.SurName;
                    dbItem.Age = model.Age;
                    dbItem.Patronymic = model.Patronymic;
                    dbItem.City = model.City;                 // в похожем месте в МЕТОДИЧКЕ опечатка, справа должно быть model.{property}
                    dbItem.Experience = model.Experience;
                }
                else
                {
                    _workersData.AddNew(model);
                }
                _workersData.Commit();
                return RedirectToAction(nameof(Index));
            }
            // Если не валидна, возвращаем её на представление
            return View(model);
        }

        [Route("delete/{id}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult Delete(int id)
        {
            _workersData.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}