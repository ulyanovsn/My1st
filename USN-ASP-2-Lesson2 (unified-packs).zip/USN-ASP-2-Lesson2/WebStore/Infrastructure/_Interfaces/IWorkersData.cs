﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebStore.DomainNew.Models;

namespace WebStore.Infrastructure.Interfaces
{
    public interface IWorkersData
    {
        
        IEnumerable<WorkerView> GetAll();
        
        WorkerView GetById(int id);
        
        void Commit();

        void AddNew(WorkerView model);
       
        void Delete(int id);
    }
}
