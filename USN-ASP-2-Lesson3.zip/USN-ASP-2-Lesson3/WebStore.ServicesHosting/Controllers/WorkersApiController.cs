﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebStore.DomainNew.Models;
using WebStore.Interfaces;

namespace WebStore.ServicesHosting.Controllers
{
    //[Produses("application/json")] -- такая строчка не генерируется, а если её поставить руками, он её не понимает
    [Route("api/workers")]           // генерируется в виде  [Route("api/[controller]")]
    [ApiController]
    public class WorkersApiController : ControllerBase, IWorkersData
    {
        private readonly IWorkersData _workersData;
        public WorkersApiController(IWorkersData workersData)
        {
            _workersData = workersData ?? throw new ArgumentNullException(nameof(workersData));
        }

        // POST api/workers
        [HttpPost]
        public void AddNew([FromBody]WorkerView model)
        {
            throw new NotImplementedException();
        }
        // DELETE api/workers/{id}
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _workersData.Delete(id);
        }
        // GET api/workers
        [HttpGet]
        public IEnumerable<WorkerView> GetAll()
        {
            return _workersData.GetAll();
        }
        // GET api/workers/{id}
        [HttpGet("{id}")]
        public WorkerView GetById(int id)
        {
            return _workersData.GetById(id);
        }
        // PUT api/workers/{id}
        [HttpPut("{id}")]
        public WorkerView UpdateWorker(int id, [FromBody]WorkerView entity)
        {
            return _workersData.UpdateWorker(id, entity);
        }
    }
}