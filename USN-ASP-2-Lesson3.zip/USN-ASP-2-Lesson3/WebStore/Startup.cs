﻿/***********************************************************
 * 
 * Это Стартап-файл основного приложеия ВебСтор
 * This Sturtup file contains in general WebStore project
 * 
 ***********************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using WebStore.DAL.Context;
using WebStore.DomainNew.Entities;
using WebStore.Implementations;
using WebStore.Implementations.Sql;
using WebStore.Clients.Services.Values;
using WebStore.Interfaces;
using WebStore.Interfaces.Api;
using WebStore.Clients.Services.Workers;
using WebStore.Clients.Services.Products;
using WebStore.Interfaces.Services;
using WebStore.Clients.Services.Orders;
using WebStore.Clients.Services.Users;

namespace WebStore
{
    public class Startup
    {
        
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();          // подключаем MVC

            #region Old Dependencies Injections
            //services.AddSingleton<IWorkersData, InMemoryWorkersData>();   // разрешаем зависимость для контролера Home
            //services.AddSingleton<IProductData, InMemoryProductData>();   // разрешаем зависимость для Каталога
            //services.AddTransient<IProductData, SqlProductData>();        // разрешаем зависимость для продуктов через БД
            //services.AddTransient<IOrdersService,   SqlOrdersService>();            // разрешаем зависимость для заказов через БД
            #endregion

            // Разрешаем зависимости для сервисов через клиентов
            services.AddTransient<IValuesService,   ValuesClient>();
            services.AddTransient<IWorkersData,     WorkersClient>();               // разрешаем зависимость для контролера Home
            services.AddTransient<IProductData,     ProductsClient>();              // разрешаем зависимость для продуктов через БД
            services.AddTransient<IOrdersService,   OrdersClient>();            // разрешаем зависимость для заказов через БД

            // интерфейс для Юзерсклиент и все вложенные интерфейсы реализуем через Юзерсклиент-класс
            services.AddTransient<IUsersClient,                 UsersClient>();
            services.AddTransient<IUserStore<User>,             UsersClient>();
            services.AddTransient<IUserRoleStore<User>,         UsersClient>();
            services.AddTransient<IUserClaimStore<User>,        UsersClient>();
            services.AddTransient<IUserPasswordStore<User>,     UsersClient>();
            services.AddTransient<IUserTwoFactorStore<User>,    UsersClient>();
            services.AddTransient<IUserEmailStore<User>,        UsersClient>();
            services.AddTransient<IUserPhoneNumberStore<User>,  UsersClient>();
            services.AddTransient<IUserLoginStore<User>,        UsersClient>();
            services.AddTransient<IUserLockoutStore<User>,      UsersClient>();
            services.AddTransient<IRoleStore<IdentityRole>,     RolesClient>();

            #region Old DB Connectings and Identity registration
            /*
            // удалим подключения к БД, это будет делаться через клиентов
            services.AddDbContext<WebStoreContext> 
                (options => options.UseSqlServer( Configuration.GetConnectionString("DefaultConnection")));

            // здесь мы добавляем Айдентити
            services.AddIdentity<User, IdentityRole>()
                    .AddEntityFrameworkStores<WebStoreContext>()          // добавляем хранилище данных
                    .AddDefaultTokenProviders();
            */
            #endregion

            // здесь мы добавляем Айдентити без объявления хранилища
            services.AddIdentity<User, IdentityRole>().AddDefaultTokenProviders();

            // здесь мы конфигурируем Айдентити
            services.Configure<IdentityOptions>(options =>
            {
                // Password settings
                options.Password.RequiredLength = 6;                     
                // Lockout settings
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(30);
                options.Lockout.MaxFailedAccessAttempts = 10;
                options.Lockout.AllowedForNewUsers = true;
                // User settings
                options.User.RequireUniqueEmail = true;
            });
            // здесь мы конфигурируем куки
            services.ConfigureApplicationCookie(options =>
            {
                // Cookie settings
                options.Cookie.HttpOnly   = true;
                options.Cookie.Expiration = TimeSpan.FromDays(150);
                options.LoginPath         = "/Account/Login";         // If the LoginPath is not set here, ASP.NET Core will default to /Account/Login
                options.LogoutPath        = "/Account/Logout";        // If the LogoutPath is not set here, ASP.NET Core will default to / Account / Logout
                options.AccessDeniedPath  = "/Account/AccessDenied";  // If the AccessDeniedPath is not set here, ASP.NET Core will default to / Account / AccessDenied
                options.SlidingExpiration = true;
            });
            //Настройки для корзины
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<ICartService,            CookieCartService>();

            
        } 

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
  
            app.UseStaticFiles();             // Добавляем расширение для использования статических файлов 
            app.UseWelcomePage("/welcome");   // Добавляем welcome-страницу
            app.UseAuthentication();          // Добавляем аутентификацию
            
            //Добавляем обработку запросов в mvc-формате
            app.UseMvc(routes =>
            {
                // Добавляем код, конфигурирующий Область Админа (предложено добавить при создании области ScaffoldingReadMe.txt)
                routes.MapRoute(
                  name: "areas",
                  template: "{area:exists}/{controller=Home}/{action=Index}/{id?}"
                );

                // Страница, на которую переходим по умолчанию при заходе на сайт
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
            
        }
    }
}
