﻿using System.Collections.Generic;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using WebStore.Clients.Base;
using WebStore.DomainNew.Models;
using WebStore.Interfaces;
namespace WebStore.Clients.Services.Workers
{
    public class WorkersClient : BaseClient, IWorkersData
    {
        public WorkersClient(IConfiguration configuration) : base(configuration)
        {
        ServiceAddress = "api/workers";
        }
        protected sealed override string ServiceAddress { get; set; }

        public IEnumerable<WorkerView> GetAll()
        {
            var url = $"{ServiceAddress}";
            var list = Get<List<WorkerView>>(url);
            return list;
        }
        public WorkerView GetById(int id)
        {
            var url = $"{ServiceAddress}/{id}";
            var result = Get<WorkerView>(url);
            return result;
        }
        public WorkerView UpdateWorker(int id, WorkerView entity)
        {
            var url = $"{ServiceAddress}/{id}";
            var response = Put(url, entity);
            var result = response.Content.ReadAsAsync<WorkerView>().Result;
            return result;
        }
        public void AddNew(WorkerView model)
        {
            var url = $"{ServiceAddress}";
            Post(url, model);
        }
        public void Delete(int id)
        {
            var url = $"{ServiceAddress}/{id}";
            Delete(url);
        }
        
    }
}