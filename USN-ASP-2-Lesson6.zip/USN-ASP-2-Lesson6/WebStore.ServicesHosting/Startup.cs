﻿/***********************************************************
 * 
 * Это Стартап-файл Сервис-Хостинга
 * This Sturtup file contains in ServiceHosting project
 * 
 ***********************************************************/
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using WebStore.Interfaces;
using WebStore.Implementations;
using WebStore.Implementations.Sql;
using WebStore.DAL.Context;
using Microsoft.EntityFrameworkCore;
using WebStore.Interfaces.Services;
using Microsoft.AspNetCore.Identity;
using WebStore.DomainNew.Entities;
using System;
using WebStore.Logger;
using WebStore.Services.Middleware;

namespace WebStore.ServicesHosting
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.AddSingleton<IWorkersData,     InMemoryWorkersData>();     // разрешаем зависимость для контролера Home
            //services.AddSingleton<IProductData,   InMemoryProductData>();     // разрешаем зависимость для Каталога

            services.AddTransient<IProductData,     SqlProductData>();          // разрешаем зависимость для продуктов через БД
            services.AddTransient<IOrdersService,   SqlOrdersService>();        // разрешаем зависимость для заказов через БД
            services.AddTransient<ILogger,          Log4NetLogger>();
            // Настройка Identity
            services.AddIdentity<User, IdentityRole>()
            .AddEntityFrameworkStores<WebStoreContext>()
            .AddDefaultTokenProviders();

            services.Configure<IdentityOptions>(options =>
            {
                // Password settings
                options.Password.RequiredLength = 6;
                // Lockout settings
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(30);
                options.Lockout.MaxFailedAccessAttempts = 10;
                options.Lockout.AllowedForNewUsers = true;
                // User settings
                options.User.RequireUniqueEmail = true;
            });

            services.AddDbContext<WebStoreContext>
                (options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            loggerFactory.AddLog4Net();
            app.UseHttpsRedirection();
            app.UseMiddleware(typeof(ErrorHandlingMiddleware));  // логирование ошибок с выводом конкретики
            app.UseMvc();
        }
    }
}
