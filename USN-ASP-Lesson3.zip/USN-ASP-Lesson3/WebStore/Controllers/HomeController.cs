﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using WebStore.Models;

namespace WebStore.Controllers
{
    public class HomeController : Controller
    {
        /// <summary>
        /// Список сотрудников
        /// </summary>
        private readonly List<WorkerView> _workers = new List<WorkerView>
        {
        new WorkerView
        {
        Id = 1,
        FirstName = "Иван" ,
        SurName = "Иванов" ,
        Patronymic = "Иванович" ,
        Age = 22,
        Experience=10,
        City="Москва"
        },
        new WorkerView
        {
        Id = 2,
        FirstName = "Пётр" ,
        SurName = "Петров" ,
        Patronymic = "Петрович" ,
        Age = 35,
        Experience=8,
        City="С.-Петербург"
        },
        new WorkerView
        {
        Id = 3,
        FirstName = "Фёдор" ,
        SurName = "Фёдоров" ,
        Patronymic = "Фёдорович" ,
        Age = 32,
        Experience=11,
        City="Н.Новгород"
        }
    };

        public IActionResult Index()                        // страница Index
        {
            return View(_workers);
        }

        public IActionResult Details(int workerId)          // страница details
        {
            foreach (var worker in _workers) if (worker.Id == workerId)
            return View(worker);                //возвращаем сотрудника
            return NotFound();                  //иначе возвращаем результат 404 Not Found
        }

        public IActionResult Shop()                         // страница shop
        {
            return View();
        }

        public IActionResult ProductDetails()               // страница product-details
        {
            return View();
        }

        public IActionResult Login()                        // страница login
        {
            return View();
        }

        public IActionResult ContactUs()                    // страница contact-us
        {
            return View();
        }

        public IActionResult Checkout()                     // страница checkout
        {
            return View();
        }

        public IActionResult Cart()                         // страница cart
        {
            return View();
        }

        public IActionResult BlogSingle()                   // страница blog-single
        {
            return View();
        }

        public IActionResult Blog()                         // страница blog
        {
            return View();
        }

        public IActionResult NotFound()                     // страница 404
        {
            return View();
        }
    }
}