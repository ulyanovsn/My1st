﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using WebStore.Models;
using WebStore.Infrastructure.Interfaces;

namespace WebStore.Controllers
{
   // [Route("users")]
    public class HomeController : Controller
    {
        /// <summary>
        /// Список сотрудников
        /// </summary>
        /* private readonly List<WorkerView> _workers = new List<WorkerView>
         {
         new WorkerView
         {
         Id = 1,
         FirstName = "Иван" ,
         SurName = "Иванов" ,
         Patronymic = "Иванович" ,
         Age = 22,
         Experience=10,
         City="Москва"
         },
         new WorkerView
         {
         Id = 2,
         FirstName = "Пётр" ,
         SurName = "Петров" ,
         Patronymic = "Петрович" ,
         Age = 35,
         Experience=8,
         City="С.-Петербург"
         },
         new WorkerView
         {
         Id = 3,
         FirstName = "Фёдор" ,
         SurName = "Фёдоров" ,
         Patronymic = "Фёдорович" ,
         Age = 32,
         Experience=11,
         City="Н.Новгород"
         }
         };*/

        private readonly IWorkersData _workersData;

        public HomeController(IWorkersData workersData)
        {
            _workersData=workersData;
        }
        public IActionResult Index()                        // страница Index
        {
            //throw new System.ApplicationException("Ошибка!");
            return View( _workersData.GetAll() );
        }

        //[Route("{id}")]
        public IActionResult Details(int id)          // страница details
        {
            var worker = _workersData.GetById(id);

            if (ReferenceEquals(worker, null)) return NotFound(); // ошибка 404
            return View(worker);                //возвращаем сотрудника
        }

        public IActionResult Shop()                         // страница shop
        {
            return View();
        }

        public IActionResult ProductDetails()               // страница product-details
        {
            return View();
        }

        public IActionResult Login()                        // страница login
        {
            return View();
        }

        public IActionResult ContactUs()                    // страница contact-us
        {
            return View();
        }

        public IActionResult Checkout()                     // страница checkout
        {
            return View();
        }

        public IActionResult Cart()                         // страница cart
        {
            return View();
        }

        public IActionResult BlogSingle()                   // страница blog-single
        {
            return View();
        }

        public IActionResult Blog()                         // страница blog
        {
            return View();
        }

        public IActionResult NotFound()                     // страница 404
        {
            return View();
        }

        
        [Route("edit/{id?}")]
        public IActionResult Edit(int? id)
        {
            WorkerView model;
            if (id.HasValue)
            {
                model = _workersData.GetById(id.Value);
                if (ReferenceEquals(model, null)) return NotFound(); // возвращаем результат 404 Not Found
            }
            else
            {
                model = new WorkerView();
            }
            return View(model);
        }
        [HttpPost]
        [Route("edit/{id?}")]
        public IActionResult Edit(WorkerView model)
        {
            if (model.Id > 0)
            {
                var dbItem = _workersData.GetById(model.Id);
                if (ReferenceEquals(dbItem, null)) return NotFound();      // возвращаем результат 404 Not Found

                dbItem.FirstName  = model.FirstName;
                dbItem.SurName    = model.SurName;
                dbItem.Age        = model.Age;
                dbItem.Patronymic = model.Patronymic;
                dbItem.City       = model.City;                 // в похожем месте в МЕТОДИЧКЕ опечатка, справа должно быть model.{property}
                dbItem.Experience = model.Experience;
            }
            else
            {
                _workersData.AddNew(model);
            }
            _workersData.Commit();
            return RedirectToAction(nameof(Index));
        }

        [Route("delete/{id}")]
        public IActionResult Delete(int id)
            {
                 _workersData.Delete(id);
                return RedirectToAction(nameof(Index));
            }
    }
}