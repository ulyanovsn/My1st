﻿namespace WebStore.DomainNew.Model
{
    public static class Const
    {
        public static class Roles
        {
            public const string Administrator = "Administrator";
            public const string User = "User";
            // Routes
            public const string deleteRoute = "delete";
            public const string getRoleIdRoute = "RoleId";
            public const string getRoleNameRoute = "RoleName/Get";
            public const string setRoleNameRoute = "RoleName/Set";
            public const string getNormalizedRoleNameRoute = "NormalizedRoleName/Get";
            public const string setNormalizedRoleNameRoute = "NormalizedRoleName/Set";
            public const string findByIdRoute = "ById/Find";
            public const string findByNameRoute = "ByName/Find";
        }
        public static class Emails
        {
            public const string Administrator = "admin@mail.com";
        }
        public static class Pass
        {
            public const string Administrator = "admin";
        }
    }
}
