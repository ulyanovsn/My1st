﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using WebStore.Models;
using WebStore.Interfaces;
using Microsoft.AspNetCore.Authorization;

namespace WebStore.Controllers
{
   // [Route("users")]
    public class HomeController : Controller
    {
        
        /*private readonly IValuesService _valuesService;
        public HomeController(IValuesService valuesService)
        {
            _valuesService = valuesService;
        }
        private readonly IWorkersData _workersData;

        public async Task<IActionResult> Index()
        {
            var values = await _valuesService.GetAsync();
            return View(values);
        }*/

        public HomeController(IWorkersData workersData)
        {
            _workersData=workersData;
        }
        public async Task<IActionResult> Index()                        // страница Index
        {
            return View( _workersData.GetAll() );
        }


        //[Route("{id}")]
        public IActionResult Details(int id)          // страница details
        {
            var worker = _workersData.GetById(id);

            if (ReferenceEquals(worker, null)) return NotFound(); // ошибка 404
            return View(worker);                //возвращаем сотрудника
        }

       

        public IActionResult ContactUs()                    // страница contact-us
        {
            return View();
        }

        public IActionResult Checkout()                     // страница checkout
        {
            return View();
        }

        /*public IActionResult Cart()                         // страница cart
        {
            return View();
        }*/

        public IActionResult BlogSingle()                   // страница blog-single
        {
            return View();
        }

        public IActionResult Blog()                         // страница blog
        {
            return View();
        }

        public IActionResult NotFound()                     // страница 404
        {
            return View();
        }

        [Route("edit/{id?}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult Edit(int? id)
        {
            WorkerView model;
            if (id.HasValue)
            {
                model = _workersData.GetById(id.Value);
                if (ReferenceEquals(model, null)) return NotFound(); // возвращаем результат 404 Not Found
            }
            else
            {
                model = new WorkerView();
            }
            return View(model);
        }
        [HttpPost]
        [Route("edit/{id?}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult Edit(WorkerView model)
        {
            if (model.Age < 18 && model.Age > 100)
            {
                ModelState.AddModelError("Age", "Ошибка возраста!");
            }
            // Проверяем модель на валидность
            if (ModelState.IsValid)
            { 
                if (model.Id > 0)
            {
                var dbItem = _workersData.GetById(model.Id);
                if (ReferenceEquals(dbItem, null)) return NotFound();      // возвращаем результат 404 Not Found

                dbItem.FirstName  = model.FirstName;
                dbItem.SurName    = model.SurName;
                dbItem.Age        = model.Age;
                dbItem.Patronymic = model.Patronymic;
                dbItem.City       = model.City;                 // в похожем месте в МЕТОДИЧКЕ опечатка, справа должно быть model.{property}
                dbItem.Experience = model.Experience;
            }
            else
            {
                _workersData.AddNew(model);
            }
            _workersData.Commit();
            return RedirectToAction(nameof(Index));
            }
            // Если не валидна, возвращаем её на представление
            return View(model);
        }

        [Route("delete/{id}")]
        [Authorize(Roles = "Administrator")]
        public IActionResult Delete(int id)
            {
                 _workersData.Delete(id);
                return RedirectToAction(nameof(Index));
            }
    }
}