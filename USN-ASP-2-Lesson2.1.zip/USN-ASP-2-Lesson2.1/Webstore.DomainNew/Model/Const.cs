﻿namespace WebStore.DomainNew.Model
{
    public static class Const
    {
        public static class Roles
        {
            public const string Administrator = "Administrator";
            public const string User = "User";
        }
        public static class Emails
        {
            public const string Administrator = "admin@mail.com";
        }
        public static class Pass
        {
            public const string Administrator = "admin";
        }
    }
}
