﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using WebStore.DAL.Context;
using WebStore.DomainNew.Entities;
using WebStore.DomainNew.Model;

namespace WebStore
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //BuildWebHost(args).Run();

            var host = BuildWebHost(args);
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                try
                {
                    var context = services.GetRequiredService<DAL.Context.WebStoreContext>();
                    Data.DbInitializer.Initialize(context);

                    //здесь мы вносим роли в базу данных
                    SetRolesToDatabase(context);
                }
                catch (Exception ex)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();
                    logger.LogError(ex, "An error occurred while seeding the database.");
                }
            }
            host.Run();
        }

        //вносим роли в базу данных
        private static void SetRolesToDatabase(WebStoreContext context)
        {
            var roleStore = new RoleStore<IdentityRole>(context);
            var roleManager = new RoleManager<IdentityRole>(
                roleStore,
                new IRoleValidator<IdentityRole>[] { },
                new UpperInvariantLookupNormalizer(),
                new IdentityErrorDescriber(), null);

            if (!roleManager.RoleExistsAsync(Const.Roles.User).Result)
            {
                var role = new IdentityRole(Const.Roles.User);
                var result = roleManager.CreateAsync(role).Result;
            }
            if (!roleManager.RoleExistsAsync(Const.Roles.Administrator).Result)
            {
                var role = new IdentityRole(Const.Roles.Administrator);
                var result = roleManager.CreateAsync(role).Result;
            }

            var userStore = new UserStore<User>(context);
            var userManager = new UserManager<User>(userStore,
                new OptionsManager<IdentityOptions>(
                    new OptionsFactory<IdentityOptions>(
                        new IConfigureOptions<IdentityOptions>[] { },
                        new IPostConfigureOptions<IdentityOptions>[] { })),
                new PasswordHasher<User>(),
                new IUserValidator<User>[] { },
                new IPasswordValidator<User>[] { },
                new UpperInvariantLookupNormalizer(),
                new IdentityErrorDescriber(), null, null);

            if (userStore.FindByEmailAsync(Const.Emails.Administrator, CancellationToken.None).Result == null)
            {
                var user = new User() { UserName = "Admin", Email = Const.Emails.Administrator };
                var result = userManager.CreateAsync(user, Const.Pass.Administrator).Result;
                if (result == IdentityResult.Success)
                {
                    var roleResult = userManager.AddToRoleAsync(
                        user,
                        Const.Roles.Administrator).Result;
                }
            }
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}
