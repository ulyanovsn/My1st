﻿namespace WebStore.Models
{
    public class WorkerView
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string Patronymic { get; set; }
        public string SurName { get; set; }
        public int Age { get; set; }
        public int Experience { get; set; }
        public string City { get; set; }
    }
}
