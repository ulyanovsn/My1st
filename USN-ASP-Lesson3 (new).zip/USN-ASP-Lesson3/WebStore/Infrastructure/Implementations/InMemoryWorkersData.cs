﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebStore.Infrastructure.Interfaces;
using WebStore.Models;

namespace WebStore.Infrastructure.Implementations
{
    public class InMemoryWorkersData : IWorkersData
    {
        private readonly List<WorkerView> _workers;

        public InMemoryWorkersData()
        {
            _workers = new List<WorkerView>
        {
        new WorkerView
        {
        Id = 1,
        FirstName = "Иван" ,
        SurName = "Иванов" ,
        Patronymic = "Иванович" ,
        Age = 22,
        Experience=10,
        City="Москва"
        },
        new WorkerView
        {
        Id = 2,
        FirstName = "Пётр" ,
        SurName = "Петров" ,
        Patronymic = "Петрович" ,
        Age = 35,
        Experience=8,
        City="С.-Петербург"
        },
        new WorkerView
        {
        Id = 3,
        FirstName = "Фёдор" ,
        SurName = "Фёдоров" ,
        Patronymic = "Фёдорович" ,
        Age = 32,
        Experience=11,
        City="Н.Новгород"
        }
    };
        }
        public void AddNew(WorkerView model)
        {
            model.Id = _workers.Max(w => w.Id) + 1;
            _workers.Add(model);
        }

        public void Commit()
        {
            // 
        }

        public void Delete(int id)
        {
            WorkerView theWorker = GetById(id);
            if (theWorker != null)
            {
                _workers.Remove(theWorker);
            }
        }

        public IEnumerable<WorkerView> GetAll()
        {
            return _workers;
        }

        public WorkerView GetById(int id)
        {
            return _workers.FirstOrDefault( w => w.Id.Equals(id) );
        }
    }
}
