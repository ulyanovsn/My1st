﻿using Microsoft.AspNetCore.Identity;

namespace WebStore.DomainNew.Entities
{
    public class User : IdentityUser
    {
    }
}
