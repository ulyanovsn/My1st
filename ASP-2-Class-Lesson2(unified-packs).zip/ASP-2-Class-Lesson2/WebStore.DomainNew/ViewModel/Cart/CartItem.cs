﻿namespace WebStore.DomainNew.ViewModel.Cart
{
    public class CartItem
    {
        public int ProductId { get; set; }

        public int Quantity { get; set; }
    }
}
