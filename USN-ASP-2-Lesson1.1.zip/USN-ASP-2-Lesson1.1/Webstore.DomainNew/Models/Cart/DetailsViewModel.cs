﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebStore.DomainNew.Models.Order;

namespace WebStore.DomainNew.Models.Cart
{
    // Модель данных для Деталей заказа: включает модель карзины и модель заказа, каждая для своего частичного представления
    public class DetailsViewModel
    {
        public CartViewModel CartViewModel { get; set; }
        public OrderViewModel OrderViewModel { get; set; }
    }
}
