﻿using System.ComponentModel.DataAnnotations;

namespace WebStore.Models
{
    public class WorkerView
    {
        public int Id { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Имя является обязательным")]
        [StringLength(maximumLength: 200, MinimumLength = 2, ErrorMessage = "В имени должно быть не менее 2-х и не более 200 символов")]
        [Display(Name = "Имя")]
        public string FirstName { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Фамилия является обязательной")]
        [Display(Name = "Фамилия")]
        public string Patronymic { get; set; }

        [Display(Name = "Отчество")]
        public string SurName { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Возраст является обязательным")]
        [Display(Name = "Возраст")]
        public int Age { get; set; }

        [Display(Name = "Опыт работы")]
        public int Experience { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Город является обязательным")]
        [Display(Name = "Город")]
        public string City { get; set; }
    }
}
