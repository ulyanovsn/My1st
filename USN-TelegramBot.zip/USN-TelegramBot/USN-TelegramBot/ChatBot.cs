﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USN_TelegramBot
{
    class ChatBot
    {
        public enum Languages { English, Russian}
        public Languages Language { get; set; }

        Dictionary<string, string> dB;
        Dictionary<string, string> dBEng = new Dictionary<string, string>();
        Dictionary<string, string> dBRus = new Dictionary<string, string>();
        public string StopResponse { get; set; }
        public string StopRequest { get; set; }
        public bool IsWorking { get; private set; }
        public ChatBot()
        {
            StopRequest = "bye";
            StopResponse = "Bye, my friend! See you!";
            IsWorking = true;

            var datas = System.IO.File.ReadAllText(@"DictionaryEng.json");
            dBEng = JsonConvert.DeserializeObject<Dictionary<string, string>>(datas);

            datas = System.IO.File.ReadAllText(@"DictionaryRus.json");
            dBRus = JsonConvert.DeserializeObject<Dictionary<string, string>>(datas);

            Language = Languages.English;
            dB = dBEng;

            #region old
            //dB.Add("hello",                 "Hi!");
            //dB.Add("hi",                    "Hello!");
            //dB.Add("what is your name",     "I am Robot!");
            //dB.Add("how are you",           "I'm Ok, thank you!");
            //dB.Add("thank you",             "Ok, thank you too!");
            //dB.Add("how much is the fish",  "la-la-la-la-la-la!");
            #endregion
        }
        public string GetTimeOfDay()
        {
            int currentHour = DateTime.Now.TimeOfDay.Hours;
            if (currentHour < 5) return (Language==Languages.English)? "Now it is night" : "Сейчас ночь";
            if (currentHour < 12) return (Language == Languages.English) ? "Now it is morning" : "Сейчас утро";
            if (currentHour < 18) return (Language == Languages.English) ? "Now is afternoon" : "Сейчас день деньской";
            return (Language == Languages.English) ? "Now is evening" : "Сейчас вечер";
        }
        public string GetResponse(string request)
        {
            string response = String.Empty;
            if (request.Contains(StopRequest))
            {
                IsWorking = false;
                return StopResponse;
            }
            else
            {
                foreach (var item in dB.Keys)
                    if (request.Contains(item))
                    {
                        response += dB[item];
                    }
                if (request.Contains("what time is it"))
                    switch(Language)
                    {
                        case Languages.English: response += "Now " + DateTime.Now.ToString("HH:mm:ss"); break;
                        case Languages.Russian: response += "Сейчас " + DateTime.Now.ToString("HH:mm:ss"); break;
                    }                 
                if (request.Contains("what date now"))
                    switch (Language)
                    {
                        case Languages.English: response += "Now " + DateTime.Now.ToString("dd:MM:yyyy"); break;
                        case Languages.Russian: response += "Сейчас " + DateTime.Now.ToString("dd:MM:yyyy"); break;
                    }
                
                if (request.Contains("how old are you"))
                    switch (Language)
                    {
                        case Languages.English: response += "I'm " + (DateTime.Now.Year - 2019).ToString() + " years old"; break;
                        case Languages.Russian: response += "Мне " + (DateTime.Now.Year - 2019).ToString() + " лет"; break;
                    }
               
                if (request.Contains("what day of week"))
                    response += "Now " + DateTime.Now.DayOfWeek.ToString();

                if (request.Contains("what time of day"))
                    response += GetTimeOfDay();

                if (request.Contains("let's russian"))
                {
                    response += "По-русски так по-русски";
                    Language = Languages.Russian;
                    dB = dBRus;
                }
                if (request.Contains("давай снова по-английки")|| request.Contains("let's english"))
                {
                    response += "Ok, let’s do it";
                    Language = Languages.English;
                    dB = dBEng;
                }

                return (response == String.Empty) ? "I don't understand you / Не понимаю тебя" : response;
            }
        }
    }
}
