﻿namespace USN_TelegramBot
{
    public class Message
    {
        public Chat Chat { get; set; }
        public string Text { get; set; }
    }
}