﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace USN_TelegramBot
{
    class ApiResult
    {
        public Update[] result { get; set; }
    }
}
