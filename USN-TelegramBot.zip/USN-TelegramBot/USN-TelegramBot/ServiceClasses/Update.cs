﻿namespace USN_TelegramBot
{
    public class Update
    {
        public int UpdateId { get; set; }
        public Message Message { get; set; }
    }
}