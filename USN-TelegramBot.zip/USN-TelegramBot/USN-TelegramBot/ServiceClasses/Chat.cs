﻿namespace USN_TelegramBot
{
    public class Chat
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
    }
}