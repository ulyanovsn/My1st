﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using RestSharp;

namespace USN_TelegramBot
{
    class TelegramAPI
    {
        string ApiUrl;
        RestClient RC = new RestClient();
        int lastUpdateId = 0;

        public TelegramAPI(string ApiKey)
        {
            ApiUrl = "https://api.telegram.org/bot" + ApiKey + "/";
        }
        
        public void SendMessage(int chatId, string text)
        {
            SendApiRequest("sendMessage", $"chat_id={chatId}&text={text}");
        }

        public Update[] GetUpdates()
        {
            var json = SendApiRequest("getUpdates", $"offset={lastUpdateId}");
            var apiResult = JsonConvert.DeserializeObject<ApiResult>(json);
            foreach (var update in apiResult.result)
            {
                //Console.WriteLine($"Has got Message number {update.UpdateId} from {update.Message.Chat.FirstName}, text: {update.Message.Text}");
                lastUpdateId = update.UpdateId + 1;
            }
            return apiResult.result;
        }

        public string SendApiRequest(string ApiMethod, string Params)
        {
            var Url = ApiUrl + "?" + Params;
            var request = new RestRequest(Url);
            var response = RC.Get(request);
            return response.Content;
        }
    }
    
}
