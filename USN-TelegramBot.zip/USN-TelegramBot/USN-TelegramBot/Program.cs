﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Newtonsoft.Json;

/*
 * Chat-bot program for Telegram API
 * Author: Ulyanov Sergey
 */

namespace USN_TelegramBot
{
    public class ConsoleBot
    {
        public void Run()
        {
            ChatBot robot = new ChatBot();
            WriteLine("Welcome to robot chat!");
            while (robot.IsWorking)
            {
                Write("You say: ");
                string request = ReadLine().ToLower();
                string response = robot.GetResponse(request);
                WriteLine("Robot says: " + response);
            }
            ReadKey();
        }
    }
    public class ApiBot
    {
        const string ApiKey = "1008135473:AAEWVrf6IapoAwXeMYj5jpRRU8-murCc34I";
        public void Run()
        {
            TelegramAPI api = new TelegramAPI(ApiKey);
            ChatBot robot = new ChatBot();
            //api.SendMessage(1010874053, "Hello");
            while (true)
            {
                var updates = api.GetUpdates();
                foreach ( var update in updates)
                if(update.Message.Text!=null && update.Message.Chat.FirstName!=null)
                {
                    string request = update.Message.Text.ToLower();
                    string response = $"Dear, {update.Message.Chat.FirstName}" + robot.GetResponse(request);
                    api.SendMessage(update.Message.Chat.Id, response);
                }
            }
            
        }
    }
    class Program
    {      
        static void Main(string[] args)
        {
            //ConsoleBot consoleBot = new ConsoleBot();
            //consoleBot.Run();

            ApiBot apiBot = new ApiBot();
            apiBot.Run();
        }
    }
}
