﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using WebStore.DomainNew.Models;
using WebStore.Interfaces;
using Microsoft.AspNetCore.Authorization;
using WebStore.Interfaces.Api;
using System.Threading.Tasks;

namespace WebStore.Controllers
{
    //[Route("Home")]
    public class HomeController : Controller
    {
        
        private readonly IValuesService _valuesService;
        
             
        public HomeController(IValuesService valuesService)
        {
            
            _valuesService = valuesService;
        }

        //[Route("Index/{id?}")]
        public async Task<IActionResult> Index(int? id)
        {
            // раскомментировать для проверки логирования ошибок:
            // throw new System.Exception("Error");
            if (id.HasValue)
            { var values = await _valuesService.GetAsync(id.Value); return View(values); }
            else
            { var values = await _valuesService.GetAsync();         return View(values); }
            
        }

        public IActionResult ContactUs()                    // страница contact-us
        {
            return View();
        }

        public IActionResult Checkout()                     // страница checkout
        {
            return View();
        }


        public IActionResult BlogSingle()                   // страница blog-single
        {
            return View();
        }

        public IActionResult Blog()                         // страница blog
        {
            return View();
        }

        public IActionResult NotFound()                     // страница 404
        {
            return View();
        }

        public IActionResult ErrorStatus(string id)
        {
            if (id == "404") return RedirectToAction("NotFound");

            return Content($"Статуcный код ошибки: {id}");
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}