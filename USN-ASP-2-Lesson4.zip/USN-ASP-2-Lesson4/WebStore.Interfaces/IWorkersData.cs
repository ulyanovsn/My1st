﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebStore.DomainNew.Models;

namespace WebStore.Interfaces
{
    public interface IWorkersData
    {
        
        IEnumerable<WorkerView> GetAll();
        
        WorkerView GetById(int id);

        WorkerView UpdateWorker(int id, WorkerView entity);

        //void Commit();

        void AddNew(WorkerView model);
       
        void Delete(int id);
    }
}
