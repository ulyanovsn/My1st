﻿using System;

namespace Webstore.DomainNew
{
    public class Class1
    {
    }
}
